import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { productService } from '../shared/product.service';
import { product } from '../shared/product.model';

declare var M: any;

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers: [productService]
})
export class productComponent implements OnInit {

  constructor(private productService: productService) { }

  ngOnInit() {
    this.resetForm();
    this.refreshproductList();
  }

  resetForm(form?: NgForm) {
    if (form)
      form.reset();
    this.productService.selectedproduct = {
      _id: "",
      name: "",
      discriptin: "",
      price: null
    }
  }

  onSubmit(form: NgForm) {
    if (form.value._id == "") {
      this.productService.postproduct(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshproductList();
        M.toast({ html: 'Saved successfully', classes: 'rounded' });
      });
    }
    else {
      this.productService.putproduct(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshproductList();
        M.toast({ html: 'Updated successfully', classes: 'rounded' });
      });
    }
  }

  refreshproductList() {
    this.productService.getproductList().subscribe((res) => {
      this.productService.products = res as product[];
    });
  }

  onEdit(emp: product) {
    this.productService.selectedproduct = emp;
  }

  onDelete(_id: string, form: NgForm) {
    if (confirm('Are you sure to delete this record ?') == true) {
      this.productService.deleteproduct(_id).subscribe((res) => {
        this.refreshproductList();
        this.resetForm(form);
        M.toast({ html: 'Deleted successfully', classes: 'rounded' });
      });
    }
  }

}
