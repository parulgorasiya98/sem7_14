const mongoose = require('mongoose');

var product = mongoose.model('product', {
    name: { type: String },
    discription: { type: String },
    price: { type: Number },
    
});

module.exports = { product };