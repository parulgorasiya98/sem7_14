import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showlist',
  templateUrl: './showlist.component.html',
  styleUrls: ['./showlist.component.css']
})
export class ShowlistComponent implements OnInit {

  products = ['Car', 'Fan', 'Chair', 13, 50];
  constructor() {

   }

  ngOnInit() {
  }

}
